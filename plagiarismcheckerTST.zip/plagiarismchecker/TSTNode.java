import java.io.*;
import java.util.*;

class TSTNode {
    char character;
    boolean isEnd;
    TSTNode left, middle, right;
    List<String> values;

    TSTNode(char c) {
        this.character = c;
        this.values = new ArrayList<>();
    }
}

class TernarySearchTree {
    private TSTNode root;

    public void insert(String word) {
        root = insert(root, word, 0);
    }

    private TSTNode insert(TSTNode node, String word, int index) {
        char c = word.charAt(index);
        if (node == null) node = new TSTNode(c);
        if (c < node.character) {
            node.left = insert(node.left, word, index);
        } else if (c > node.character) {
            node.right = insert(node.right, word, index);
        } else {
            if (index + 1 < word.length()) {
                node.middle = insert(node.middle, word, index + 1);
            } else {
                node.isEnd = true;
                node.values.add(word);
            }
        }
        return node;
    }

    public boolean contains(String word) {
        TSTNode node = get(root, word, 0);
        return node != null && node.isEnd;
    }

    private TSTNode get(TSTNode node, String word, int index) {
        if (node == null) return null;
        char c = word.charAt(index);
        if (c < node.character) return get(node.left, word, index);
        else if (c > node.character) return get(node.right, word, index);
        else {
            if (index + 1 == word.length()) return node;
            return get(node.middle, word, index + 1);
        }
    }

    public List<String> getAllWords() {
        List<String> result = new ArrayList<>();
        collect(root, new StringBuilder(), result);
        return result;
    }

    private void collect(TSTNode node, StringBuilder prefix, List<String> result) {
        if (node == null) return;
        collect(node.left, prefix, result);
        prefix.append(node.character);
        if (node.isEnd) result.addAll(node.values);
        collect(node.middle, prefix, result);
        prefix.deleteCharAt(prefix.length() - 1);
        collect(node.right, prefix, result);
    }
}
