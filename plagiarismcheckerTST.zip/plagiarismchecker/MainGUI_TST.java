import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

// window components (text field for paths, buttons, check plagiarism, save reports, text area, report content)
public class MainGUI_TST extends JFrame {
    private JTextField fileField3, fileField4;
    private JCheckBox useTSTCheckBox;
    private JButton browseButton1, browseButton2, checkButton, saveReportButton;
    private JLabel resultLabel;
    private JTextArea matchArea;
    private String reportContent = "";

    // constructor (basic frame setup, window title, default close behavior, window, use border layout)
    public MainGUI_TST() {
        setTitle("Plagiarism Checker");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        // file panel for selecting files
        JPanel filePanel = new JPanel(new GridBagLayout()); // panel w title border n gbl (flexible layout manager)
        filePanel.setBorder(BorderFactory.createTitledBorder("Select Files"));
        GridBagConstraints gbc = new GridBagConstraints(); // define how each component will b laid out within the gbl
        gbc.insets = new Insets(10, 10, 10, 10); // px
        gbc.fill = GridBagConstraints.HORIZONTAL; // components expand horizontally to fill their grid cell

        fileField3 = new JTextField(30); // text fields
        fileField4 = new JTextField(30);
        browseButton1 = new JButton("Browse..."); // buttons
        browseButton2 = new JButton("Browse...");
        checkButton = new JButton("Check Plagiarism"); //the check plagiarism button
        saveReportButton = new JButton("Save Report");

        gbc.gridx = 0; gbc.gridy = 0;
        filePanel.add(new JLabel("File 1 :"), gbc);
        gbc.gridx = 1;
        filePanel.add(fileField3, gbc);
        gbc.gridx = 2;
        filePanel.add(browseButton1, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        filePanel.add(new JLabel("File 2 :"), gbc);
        gbc.gridx = 1;
        filePanel.add(fileField4, gbc);
        gbc.gridx = 2;
        filePanel.add(browseButton2, gbc);

        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 3;
        gbc.anchor = GridBagConstraints.CENTER;
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(checkButton);
        buttonPanel.add(saveReportButton);
        useTSTCheckBox = new JCheckBox("Use Ternary Search Tree (Fast Match)");
        useTSTCheckBox.setSelected(true); // default is TST
        buttonPanel.add(useTSTCheckBox);
        filePanel.add(buttonPanel, gbc);

        //result label display
        resultLabel = new JLabel("Result will appear here", SwingConstants.CENTER);
        resultLabel.setFont(new Font("SansSerif", Font.BOLD, 16));
        resultLabel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        //text area
        matchArea = new JTextArea();
        matchArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        matchArea.setMargin(new Insets(10, 10, 10, 10));
        matchArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(matchArea);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Similarity Report"));

        //add components to base frame
        add(filePanel, BorderLayout.NORTH); //top center bottom
        add(resultLabel, BorderLayout.CENTER);
        add(scrollPane, BorderLayout.SOUTH);

        //being able to browse files
        browseButton1.addActionListener(e -> chooseFile(fileField3));
        browseButton2.addActionListener(e -> chooseFile(fileField4));

        checkButton.addActionListener((ActionEvent e) -> {
            String file1 = fileField3.getText();
            String file2 = fileField4.getText();
            if (!file1.isEmpty() && !file2.isEmpty()) {
                try {
                    String reportPath = "plagiarism_report.txt";
                    PlagiarismCheckerTST.useTST = useTSTCheckBox.isSelected(); // update internal switch

                    Runtime rt = Runtime.getRuntime();

                    long totalMemBefore = rt.totalMemory();
                    long freeMemBefore = rt.freeMemory();
                    long usedMemBefore = totalMemBefore - freeMemBefore;

                    long startTime = System.nanoTime();

                    PlagiarismChecker.generateReport(file1, file2, "plagiarism_report.txt");

                    long endTime = System.nanoTime();
                    long elapsedMicroseconds = (endTime - startTime) / 1000;

                    long totalMemAfter = rt.totalMemory();
                    long freeMemAfter = rt.freeMemory();
                    long usedMemAfter = totalMemAfter - freeMemAfter;

                    String method = PlagiarismCheckerTST.useTST ? "TST" : "ArrayList";

                    System.out.println("Report generated using " + method);
                    System.out.println("Time elapsed: " + elapsedMicroseconds + " µs");
                    System.out.println("Memory used: " + (usedMemAfter - usedMemBefore) + " bytes");

                    reportContent = new String(java.nio.file.Files.readAllBytes(new File("plagiarism_report.txt").toPath()));
                    matchArea.setText(reportContent);

                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(MainGUI_TST.this, "Error generating report.", "Error", JOptionPane.ERROR_MESSAGE);
                    ex.printStackTrace();
                }
            } else {
                JOptionPane.showMessageDialog(MainGUI_TST.this, "Please select both files.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        saveReportButton.addActionListener(e -> saveReport());
    }

    //file browsing mechanism
    private void chooseFile(JTextField field) {
        JFileChooser fileChooser = new JFileChooser();
        int result = fileChooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            field.setText(fileChooser.getSelectedFile().getAbsolutePath());
        }
    }

    private void saveReport() {
        if (reportContent.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No report to save.", "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }
        JFileChooser fileChooser = new JFileChooser();
        int result = fileChooser.showSaveDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
                writer.write(reportContent);
                JOptionPane.showMessageDialog(this, "Report saved successfully.");
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, "Failed to save report.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainGUI_TST().setVisible(true));
    }
}